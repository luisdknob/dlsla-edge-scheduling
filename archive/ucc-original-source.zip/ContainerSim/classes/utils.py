# from containerSim.classes import Node, Image, Application, NetworkInterface, Registry

# def _extractNodeFromJSON(configJSON, images):
#     """
#     Recebe a configuração
#     """

#     nodeList = []
#     networkInterfaceList = []

#     # for netInterface in node['netint']:

#     #     net = NetworkInterface(node['name'], netInterface['connectedto'], netInterface['bandwidth'])
#     #     networkInterfaceList.append(net)

#     #     if netInterface['bidirectional'] == "true": # TODO: Boolean value

#     #         net = NetworkInterface(netInterface['connectedto'], node['name'], netInterface['bandwidth'])
#     #         networkInterfaceList.append(net)

#             # networkInterfaceList.append(dict(connectedToNodeId=node['name'], **netInterface))

#     # for node in nodeList:
#     #     for netInterface in node['netint']:
#     #         # Get Node Object from name
#     #         connectedToNodeId = list(filter(lambda item: item['name'] == netInterface['connectedto'], nodeList))[0]
#     #         networkInterfaceList.append(node.createNetworkInterface(connectedToNodeId, netInterface['bandwidth']))

#     # for netinterface in networkInterfaceList:
#     #     node = list(filter(lambda item: item['name'] == netinterface, nodeList))[0]
#     #     netInterface = NetworkInterface(fromNodeId=nodeObject.id, connectedToNodeId= , bandwidth=networkInterface['bandwidth'])
#     #     node['netint'] = netInterface
#     #     networkInterfaceList.append(netInterface)
    
#     if 'nodes' in configJSON:

#         # first create all registries
#         for registry in [registry for registry in configJSON['nodes'] if registry['type'] == 'registry']:
#             # get image objects that are configured for registry
#             images = list(filter(lambda image: image.name in registry['images'], images))

#             # remove atribute image
#             attr = {k: v for k, v in registry.items() if k not in ['images', 'type', 'networkInterface']}
#             registryObject = Registry(**attr, images=images)
#             registry['id'] = registryObject.id
#             nodeList.append(registryObject)

#         # second create all nodes object
#         for node in [chost for chost in configJSON['nodes'] if chost['type'] == 'chost']:
#             # get Registry object configured for node
#             registryConfiguredForNode = [registry for registry in nodeList 
#                                             if registry.type == 'registry' and registry.name in node['registry']]

#             # remove atribute image
#             attr = {k: v for k, v in node.items() if k not in ['registry']}
#             nodeObject = Node(**attr, registry=registryConfiguredForNode)
#             node['id'] = nodeObject.id
#             nodeList.append(nodeObject)

#         # third create all network interfaces
#         for node in configJSON['nodes']: 
#             if 'networkInterface' in node:
#                 for netInterface in node['networkInterface']:
#                     # get Node ID by name
#                     connectedToNodeId = list(filter(lambda item: item.name == netInterface['connectedto'], nodeList))[0].id

#                     # create NetworkInterface Object
#                     net = NetworkInterface(node['id'], connectedToNodeId, netInterface['bandwidth'])
#                     networkInterfaceList.append(net)

#                     if 'bidirectional' in netInterface:
#                         if netInterface['bidirectional'] == "true": # TODO: Boolean value
#                             net = NetworkInterface(connectedToNodeId, node['id'], netInterface['bandwidth'])
#                             networkInterfaceList.append(net)
#             else:
#                 raise Exception("No network interface found.")
#     else:
#         raise Exception("No nodes were found.")

#     # if 'networkInterfaces' in configJSON:
#     #     for netInterface in configJSON['networkInterfaces']:

#     return nodeList, networkInterfaceList

# # def _extractEdgesFromJSON(networkInterfacesJSON):

# #     edges = []

# #     return edges

# def _extractImageFromJSON(dataJSON):

#     if 'images' in dataJSON:
#         return [Image(**image) for image in dataJSON['images']]
#     else:
#         raise Exception('No images were found.')

# def _extractApplicationsFromJSON(dataJSON, imagesList):

#     if 'applications' in dataJSON:

#         applicationObjectList = []
#         for application in dataJSON['applications']:
#             for replica in application.numReplicas:
#                 # imageObject = list(filter(lambda row: row.name == application['imageName'], imagesList))[0]
#                 imageObject = [image for image in imagesList if image.name == application['image']][0]
#                 # remove atribute image
#                 attr = {k: v for k, v in application.items() if not k.startswith('image')}
#                 applicationObjectList.append(Application(**attr, image=imageObject))

#         return applicationObjectList

#     else:
#         raise Exception('No applications were found.')

# def _checkDataIntegrity(dataJSON):

#     # verify if all the necessary attributes are filled

#     pass

# def configurationFromJSON(dataJSON):

#     images = _extractImageFromJSON(dataJSON)

#     applications = _extractApplicationsFromJSON(dataJSON, images)

#     nodes, edges = _extractNodeFromJSON(dataJSON, images)

#     # edges = _extractEdgesFromJSON(dataJSON['networkInterfaces'])

#     registries = [node for node in nodes if node.type == 'registry']

#     chosts = [node for node in nodes if node.type == 'chost']

#     return chosts, registries, edges, images, applications

def convert_labels_to_dict(labels):
    labels_dict = dict()
    for label in labels:
        labels_dict[label["key"]] = label["value"]
    return labels_dict