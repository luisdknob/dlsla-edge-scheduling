
from classes.application import Application, Image, Layer
from classes.json import configuration_from_JSON
from classes.scheduler import KubeScheduler

from bitmath import MB, GB, Bit, Byte

class TestKubeScheduler:

    def __init__(self):
        pass

    def test_match_node_selector(self):
        
        JSON = {
            "nodes": [
                {
                    "type": "chost",
                    "name": "worker1",
                    "storageCapacity": "10000MB",
                    "cpuCapacity": 8000,
                    "memoryCapacity": "32GB",
                    "pos": [
                        -51.20744119,
                        -30.03273162
                    ],
                    "labels": {
                        "pop": "MA",
                        "bandwidth": "100Mb"
                    },
                    "registry": [
                        "registry1"
                    ]
                },
                {
                    "type": "chost",
                    "name": "worker2",
                    "storageCapacity": "10000MB",
                    "cpuCapacity": 8000,
                    "memoryCapacity": "32GB",
                    "pos": [
                        -51.20744119,
                        -30.03273162
                    ],
                    "labels": {
                        "pop": "SP",
                        "bandwidth": "100Mb"
                    },
                    "registry": [
                        "registry1"
                    ]
                },
            ],
            "layers": [
                {
                    "digest": "sha256:345e3491a907bb7c6f1bdddcf4a94284b8b6ddd77eb7d93f09432b17b20f2bbe",
                    "size": "28.5396260MB"
                },
                {
                    "digest": "sha256:57671312ef6fdbecf340e5fed0fb0863350cd806c92b1fdd7978adbd02afc5c3",
                    "size": "0.0008510MB"
                },
                {
                    "digest": "sha256:5e9250ddb7d0fa6d13302c7c3e6a0aa40390e42424caed1e5289077ee4054709",
                    "size": "0.0001870MB"
                },
                {
                    "digest": "sha256:2d512e2ff7788e9e77850c0a2830d054527a099b682ed31eadb5331161f96559",
                    "size": "0.0017480MB"
                },
                {
                    "digest": "sha256:57c1a7dc2af94808125e8bd4d5ddfe0d556ff280e6897a9cef8276e1f6225f20",
                    "size": "5.4902490MB"
                },
                {
                    "digest": "sha256:b846f4f4774a636a7aaabb0485956e0f518f82813f475c9d300620f18684244a",
                    "size": "3.6165430MB"
                },
                {
                    "digest": "sha256:66409f940bd2a845698f5b79a42c83cef49da0695a1c10dca09f100bb23ff58b",
                    "size": "0.0001490MB"
                },
                {
                    "digest": "sha256:ddfd6ea8f4b9b739ed976b9b1fd1848d5febd58303c02ac3ce75849234483244",
                    "size": "1.3164240MB"
                },
                {
                    "digest": "sha256:1e2dc4d334a0fd09200504a0f3173b7227deec27c632a208a24b49852b0d8035",
                    "size": "0.0024850MB"
                },
                {
                    "digest": "sha256:42e9f65594e2278af5f4f78cf07ab4d63d4bbd1f6b6e2d4b5a0d7d88e3ca3098",
                    "size": "0.0003270MB"
                },
                {
                    "digest": "sha256:cceed5c12f84aef17c71eb5ca00ef6b829f2b6f03ce9d381c7d06a9a42f19906",
                    "size": "86.9391400MB"
                },
                {
                    "digest": "sha256:90f64d87d4c0c3a62030bc383ed7d79ceef42bc531d1938078c3870f4bd985f4",
                    "size": "0.0055610MB"
                }
            ],
            "images": [
                {
                    "name": "mariadb",
                    "architecture": "amd64",
                    "versions": [
                        {
                            "digest": "sha256:41874af99f06dd0d01a9a08d928446a92137739012fdc502a89356dc5f8c4125",
                            "tag": "latest",
                            "layers": [
                                "sha256:345e3491a907bb7c6f1bdddcf4a94284b8b6ddd77eb7d93f09432b17b20f2bbe",
                                "sha256:57671312ef6fdbecf340e5fed0fb0863350cd806c92b1fdd7978adbd02afc5c3",
                                "sha256:5e9250ddb7d0fa6d13302c7c3e6a0aa40390e42424caed1e5289077ee4054709",
                                "sha256:2d512e2ff7788e9e77850c0a2830d054527a099b682ed31eadb5331161f96559",
                                "sha256:57c1a7dc2af94808125e8bd4d5ddfe0d556ff280e6897a9cef8276e1f6225f20",
                                "sha256:b846f4f4774a636a7aaabb0485956e0f518f82813f475c9d300620f18684244a",
                                "sha256:66409f940bd2a845698f5b79a42c83cef49da0695a1c10dca09f100bb23ff58b",
                                "sha256:ddfd6ea8f4b9b739ed976b9b1fd1848d5febd58303c02ac3ce75849234483244",
                                "sha256:1e2dc4d334a0fd09200504a0f3173b7227deec27c632a208a24b49852b0d8035",
                                "sha256:42e9f65594e2278af5f4f78cf07ab4d63d4bbd1f6b6e2d4b5a0d7d88e3ca3098",
                                "sha256:cceed5c12f84aef17c71eb5ca00ef6b829f2b6f03ce9d381c7d06a9a42f19906",
                                "sha256:90f64d87d4c0c3a62030bc383ed7d79ceef42bc531d1938078c3870f4bd985f4"
                            ]
                        }
                    ],
                    "startDelay": "TO BE DEFINED"
                },
            ],
            "applications": [
                {
                    "name": "mariadb-app-0",
                    "image": "mariadb",
                    "tag": "latest",
                    "cpuRequired": 500,
                    "memoryRequired": "256MB",
                    "labels": {
                        "selector:pop": "MA",
                        "sla": 38
                    }
                },
            ]
        }

        nodes, _, _, applications, _, _ = configuration_from_JSON(JSON)
        
        chosts = KubeScheduler()._match_node_selector(applications[0], nodes)

        print(chosts)
        
        # 1. Only the node in MA must remain
        assert all([True if 'MA' == chost['labels']['pop'] else False for chost in chosts])

        # 2. 

    def test_image_locality_priority(self, mocker):

        pass

        #     mocker.patch('classes.scheduler.KubeScheduler._get_application_layers', return_value=layers)
            
        #     chosts = KubeScheduler()._image_locality_priority(application, chosts)

        #     print(chosts)
            
        #     assert chosts[0]['score'] == 