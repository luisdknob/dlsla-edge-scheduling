import numpy as np
import pandas as pd
import json
import statistics as stats

seeds_rd = [163295,231187,231686,271284,302129,316044,331434,36166,380299,455363,477552,510818,522312,583027,606766,662709,676665,683969,715520,756473,77887,786214,795451,880670,887024,887962,923093,955775,964422]
seeds_nd = [80307,451446,215056,325884,271455,976328,58701,382594,553007,947580,942034,235125,586779,506365,656531,587302,552336,586519,777468,502567,219381,975931,795074,172779,842672,893718,710378,385919,335294,537105]
seeds_st = [738052,89256,250468,386814,441238,294683,212456,324106,686300,641185,803682,419845,258599,397908,89062,607400,654910,714640,283202,557102,170106,631806,479661,942685,982449,813031,704698,355510,844467,482017]

files_name = ["random_scenario/scenario-1-kubescheduler", "random_scenario/scenario-2-sla", "random_scenario/scenario-3-ks-infra", "normal_distribution_scenario/nd_scenario_1_ks", "normal_distribution_scenario/nd_scenario_2_sla", "normal_distribution_scenario/nd_scenario_3_infra", "todos_60/st_scenario_1_ks", "todos_60/st_scenario_2_sla",  "todos_60/st_scenario_3_infra"]
jsonFiles_name = ["rd_scenario_1_ks", "rd_scenario_2_sla", "rd_scenario_3_infra", "nd_scenario_1_ks", "nd_scenario_2_sla", "nd_scenario_3_infra", "st_scenario_1_ks", "st_scenario_2_sla", "st_scenario_3_infra"]
seeds_array = [seeds_rd, seeds_nd, seeds_st]

pd.set_option('mode.chained_assignment', None)

for i, file in enumerate(files_name):
    seeds = seeds_array[i//3]
    print("File: %s"%file)
    values = []
    for seed in seeds:
        
        with open("%s-%d-container_all_times.json"%(file, seed), "r") as f:
            jsonFile = json.load(f)
        
        df = pd.DataFrame.from_dict(jsonFile["containers"])
        
        break_names = df.name.str.split('-',5).tolist()
        new_names = list()
        new_container_names = list()
        #a = list()

        for element in break_names:
            new_names.append("%s-%s-%s-%s"%(element[0],element[1],element[2],element[3]))
            new_container_names.append("%s-%s-%s-%s-%s"%(element[0],element[1],element[2],element[3], element[4]))
            #a.append(element[0])

        df["app"] = new_names
        df["replica"] = new_container_names
        #df["container_name"] = a

        #grouped_df = df.groupby("container_name")

        #print(grouped_df.max())

        df.drop(columns = ["name","src","downloaded", "waiting_time","download_time"], inplace=True)

        grouped_df = df.groupby("replica")
        test = grouped_df.max()
        test.reset_index()

        per_host = test["dst"].value_counts().to_dict()

        grouped_df = df.groupby("app")

        maximum = grouped_df.max()
        maximum.reset_index()

        #print(maximum["instantiation_time"].describe())

        av_time = sum(maximum["instantiation_time"])/len(maximum)

        conditions = [maximum['expected_time'] > maximum["instantiation_time"], maximum['expected_time'] <= maximum["instantiation_time"]]

        maximum["sla"] = np.select(conditions,[True, False])

        n_sla = maximum["sla"].value_counts()[0]

        unfullfill_slas = maximum[maximum["sla"] == 0]
        unfullfill_slas.reset_index()
        unfullfill_slas["passtime"] = unfullfill_slas["instantiation_time"].sub(unfullfill_slas["expected_time"])
        un_slas_time = unfullfill_slas["passtime"].mean()
        avg_time = maximum["instantiation_time"].mean()

        #print({"id":int(seed), "un_slas_time":round(un_slas_time,2), "n_sla":int(n_sla)})
        values.append({"id":int(seed), "un_slas_time":round(un_slas_time,2), "avg_time":round(avg_time,2), "n_sla":int(n_sla), "per_host":per_host})

    with open("%s.json"%jsonFiles_name[i], "w") as f:
         json.dump(values, f, indent=3)