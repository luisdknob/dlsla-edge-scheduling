
# %%

import json
import bitmath
import pandas as pd
import matplotlib.pyplot as pyplot

files = ["scenario-1-kubescheduler-host_occupation", "scenario-2-sla-host_occupation", "scenario-3-ks-infra-host_occupation"]

columns = ["Kube Scheduler","SLA Deployment Latency Scheduler"]

for id, file in enumerate(files):

    csv_file =  open(file+".csv", "r")

    df = pd.read_csv(csv_file, delimiter=";")

    values = df["host"].value_counts()

    print(values.describe())

    #print(a)