import numpy as np
import pandas as pd
import json
import matplotlib.pyplot as pyplot
import matplotlib
import statistics as stats

jsonfiles = ["rd_scenario_1_ks", "rd_scenario_2_sla", "rd_scenario_3_infra", "nd_scenario_1_ks", "nd_scenario_2_sla", "nd_scenario_3_infra", "st_scenario_1_ks", "st_scenario_2_sla", "st_scenario_3_infra"]

pd.set_option('mode.chained_assignment', None)

df_all = pd.DataFrame()

for file in jsonfiles:
    with open("%s.json"%(file), "r") as f:
            jf = json.load(f)

    df = pd.DataFrame.from_dict(jf)

    #print(df)

    df_all["%s-un_slas_time"%(file)] = df["un_slas_time"]
    df_all["%s-n_sla"%(file)] = df["n_sla"]
    df_all["%s-avg_time"%(file)] = df["avg_time"]

#print(df_all)

fields = ["un_slas_time", "n_sla", "avg_time"]
graph_labels = ["Average time over the SLA to not fulfilled applications", "Number of applications that not fulfill the SLA"]
y_labels  = ["Average Time (sec)", "Applications (n)"]
graph_name = ["av_un_time", "n_sla"]

for i, field in enumerate(fields):

    groups = [{"Kube-scheduler":df_all["rd_scenario_1_ks-%s"%field].mean(), "Infra-Aware Scheduler":df_all["rd_scenario_3_infra-%s"%field].mean(), "DLSLA Scheduler":df_all["rd_scenario_2_sla-%s"%field].mean()}, {"Kube-scheduler":df_all["nd_scenario_1_ks-%s"%field].mean(), "Infra-Aware Scheduler":df_all["nd_scenario_3_infra-%s"%field].mean(), "DLSLA Scheduler":df_all["nd_scenario_2_sla-%s"%field].mean()}, {"Kube-scheduler":df_all["st_scenario_1_ks-%s"%field].mean(), "Infra-Aware Scheduler":df_all["st_scenario_3_infra-%s"%field].mean(), "DLSLA Scheduler":df_all["st_scenario_2_sla-%s"%field].mean()}]
    groups_error = [{"Kube-scheduler":df_all["rd_scenario_1_ks-%s"%field].std(), "Infra-Aware Scheduler":df_all["rd_scenario_3_infra-%s"%field].std(), "DLSLA Scheduler":df_all["rd_scenario_2_sla-%s"%field].std()}, {"Kube-scheduler":df_all["nd_scenario_1_ks-%s"%field].std(), "Infra-Aware Scheduler":df_all["nd_scenario_3_infra-%s"%field].std(), "DLSLA Scheduler":df_all["nd_scenario_2_sla-%s"%field].std()}, {"Kube-scheduler":df_all["st_scenario_1_ks-%s"%field].std(), "Infra-Aware Scheduler":df_all["st_scenario_3_infra-%s"%field].std(), "DLSLA Scheduler":df_all["st_scenario_2_sla-%s"%field].std()}]
    print(groups, groups_error)

    group_labels = ["Random Distribution", "Normal Distribution", "60 Sec SLA"]

    error_sla = pd.DataFrame(groups_error, index=group_labels)
    sla_df = pd.DataFrame(groups, index=group_labels)

    #print(sla_df)
    #print(groups_error)
    colors = ["dimgray", "silver"]
    matplotlib.rcParams.update({'errorbar.capsize': 3})

    plt = sla_df.plot.bar(figsize=(10,7), yerr=error_sla, color=colors)
    #plt.set_title(graph_labels[i])
    plt.set_xticklabels(group_labels, rotation=0)
    plt.set_ylabel(y_labels[i])
    plt.legend(loc='upper left')
    #pyplot.show()
    # pyplot.savefig("%s.png"%graph_name[i], transparent=True)

#pd.concat()