import numpy as np
import pandas as pd
import json
import matplotlib.pyplot as pyplot
import matplotlib
import statistics as stats


hosts = ['edge1', 'edge10', 'edge100', 'edge101', 'edge102', 'edge103', 'edge104', 'edge105', 'edge106', 'edge107', 'edge108', 'edge109', 'edge11', 'edge110', 'edge111', 'edge112', 'edge113', 'edge114', 'edge115', 'edge116', 'edge117', 'edge118', 'edge119', 'edge12', 'edge120', 'edge121', 'edge122', 'edge123', 'edge124', 'edge125', 'edge126', 'edge127', 'edge128', 'edge129', 'edge13', 'edge130', 'edge131', 'edge132', 'edge133', 'edge134', 'edge135', 'edge136', 'edge137', 'edge138', 'edge139', 'edge14', 'edge140', 'edge15', 'edge16', 'edge17', 'edge18', 'edge19', 'edge2', 'edge20', 'edge21', 'edge22', 'edge23', 'edge24', 'edge25', 'edge26', 'edge27', 'edge28', 'edge29', 'edge3', 'edge30', 'edge31', 'edge32', 'edge33', 'edge34', 'edge35', 'edge36', 'edge37', 'edge38', 'edge39', 'edge4', 'edge40', 'edge41', 'edge42', 'edge43', 'edge44', 'edge45', 'edge46', 'edge47', 'edge48', 'edge49', 'edge5', 'edge50', 'edge51', 'edge52', 'edge53', 'edge54', 'edge55', 'edge56', 'edge57', 'edge58', 'edge59', 'edge6', 'edge60', 'edge61', 'edge62', 'edge63', 'edge64', 'edge65', 'edge66', 'edge67', 'edge68', 'edge69', 'edge7', 'edge70', 'edge71', 'edge72', 'edge73', 'edge74', 'edge75', 'edge76', 'edge77', 'edge78', 'edge79', 'edge8', 'edge80', 'edge81', 'edge82', 'edge83', 'edge84', 'edge85', 'edge86', 'edge87', 'edge88', 'edge89', 'edge9', 'edge90', 'edge91', 'edge92', 'edge93', 'edge94', 'edge95', 'edge96', 'edge97', 'edge98', 'edge99', 'worker1', 'worker10', 'worker11', 'worker12', 'worker13', 'worker14', 'worker15', 'worker16', 'worker17', 'worker18', 'worker19', 'worker2', 'worker20', 'worker21', 'worker22', 'worker23', 'worker24', 'worker25', 'worker26', 'worker27', 'worker28', 'worker3', 'worker4', 'worker5', 'worker6', 'worker7', 'worker8', 'worker9']
jsonfiles = ["rd_scenario_1_ks", "rd_scenario_3_infra", "rd_scenario_2_sla", "nd_scenario_1_ks", "nd_scenario_3_infra", "nd_scenario_2_sla", "st_scenario_1_ks", "st_scenario_3_infra", "st_scenario_2_sla"]

pd.set_option('mode.chained_assignment', None)

dfs_alls = [[],[]]

for nf,file in enumerate(jsonfiles):
    with open("%s.json"%(file), "r") as f:
            jf = json.load(f)
    
    dfs = []
    df_all = pd.DataFrame(hosts, columns=['host'])

    for element in jf:

        df = pd.DataFrame(element["per_host"].items(), columns=['host', 'containers-%d'%element['id']])
        #print(sorted(df["host"].to_list()))
    
        df_all = pd.merge(left=df_all, right=df, how='left', left_on='host', right_on='host')
        

    df_all = df_all.fillna(0)
    df_all["container-mean"] = df_all.mean(axis=1)
    df_mean = df_all.loc[:, ("host", "container-mean")]
    #dfs_alls.append(df_mean["container-mean"].values)
    #print(df_mean)
    df_edge = df_mean[df_mean.host.str.contains("edge")]
    df_worker = df_mean[df_mean.host.str.contains("worker")]
    #print(df_edge)

    dfs_alls[0].append(df_edge["container-mean"].values)
    dfs_alls[1].append(df_worker["container-mean"].values)


#print(dfs_alls)

colors = ["silver", "dimgray", "black"]
size = [0.8,0.2]

fig, axes = pyplot.subplots(figsize=(16,10))

for i in range(0,2):
    for j, data in enumerate(dfs_alls[i]):
        print(jsonfiles[j])
        df = pd.DataFrame().from_dict({'Means': data})
        print(df[df["Means"] < 1].value_counts())

# for i in range(0,2):
# #     #axes.scatter(y = dataset, x = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16])
#       violin_parts = axes.violinplot(dataset = dfs_alls[i], showextrema=False, showmeans=True , widths=size[i])
#       violin_parts['cmeans'].set_edgecolor(colors[(i+1)])
#       for vp in violin_parts['bodies']:
#         vp.set_facecolor(colors[i])
#         vp.set_alpha(0.5)
# axes.set_xticks([0,1,2,3,4,5,6,7,8,9])        
# axes.set_xticklabels(["","Kube-scheduler","Infra-Aware\n\nRandom Distribution", "DLSLA Scheduler", "Kube-scheduler","Infra-Aware\n\nNormal Distribution","DLSLA Scheduler", "Kube-scheduler","Infra-Aware\n\n60 Sec SLA","DLSLA Scheduler"])
# axes.set_ylabel("Number of schedule containers (average)")

# legend_elements = [matplotlib.patches.Patch(facecolor='silver', edgecolor='black', lw=0, label='Edge Nodes'), matplotlib.patches.Patch(facecolor='dimgray', lw=0, label='Worker Nodes')]
# axes.legend(handles=legend_elements, loc='upper left')

#pyplot.show()
#pyplot.savefig("violin.png", transparent=True)
